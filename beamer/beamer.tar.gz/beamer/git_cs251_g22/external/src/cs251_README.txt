To build Box2D do the following:

1. Extract the Box2D archive. The sources are extracted in a folder called Box2D.

2. Change into the Box2D folder and make a new folder called "build251"

3. Now change into the build251 folder

4. Write "cmake ../" to generate a makefile

5. Write "make"

6. Write "make install"

7. Check that libBox2D.a got installed in cs251_base_code/external/lib	

8. Check that a folder got Box2D got created with include files in it, in cs251_base_code/external/include
